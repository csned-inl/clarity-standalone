#!/usr/bin/env bash
set -u
name="$1"
model="/tmp/clarity-proof-segments-dd9d/${name}.smv"
out="/tmp/clarity-proof-segment-results-dd9d"
mkdir -p "$out"
cmd="$out/${name}.cmd"
log="$out/${name}.log"
printf 'read_model -i %s\ngo_msat\ncheck_invar_ic3\nquit\n' "$model" > "$cmd"
set +e
/usr/bin/time -f 'elapsed_seconds=%e peak_kb=%M' timeout 300 /home/github-runner/tools/nuxmv/2.2.0/nuxmv-2.2.0.sh -source "$cmd" > "$log" 2>&1
status="$?"
set -e
printf 'case=%s exit=%s\n' "$name" "$status"
grep -E '^-- invariant|^-- no proof|elapsed_seconds=|peak_kb=|Command terminated' "$log" | tail -25 || true
printf 'log=%s\n' "$log"

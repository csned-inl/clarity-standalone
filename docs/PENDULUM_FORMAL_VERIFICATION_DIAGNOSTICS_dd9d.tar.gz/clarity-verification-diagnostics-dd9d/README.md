# Pendulum verification diagnostics from commit dd9d9d6

These are the exact temporary files used for the segmented diagnostics of
`csned-inl/clarity-standalone` commit
`dd9d9d6f7a435df3e11ab28b7158c16046766cdd`. They were not applied as a
source fix. Later commits on `codex/pendulum-controller-pipeline` may have
implemented different corrections.

- `models/original-generated-model.smv`: unmodified SMV emitted for the submitted Blink job (SHA-256 `72e4949d907e34b0617093a1db862e17e938c3db98a8c3d094cb6dc9d0534a9e`).
- `models/original-{voltage,feedback,envelope}.smv`: the same transition system with one `INVARSPEC` retained per file.
- `models/coupled-{feedback,envelope}.smv` and `models/controller-coupling.diff`: replace the amplifier's free availability and voltage inputs by `TRUE` and `controller_policyCall_proposedMotorVoltage`.
- `models/snapshot-feedback.smv` and `models/feedback-snapshot.diff`: record the four `encoder_reading_*` inputs alongside the issued command and compare that snapshot in the feedback property.
- `models/disabled-input-envelope.smv`: set amplifier availability to `FALSE` as a diagnostic control.
- `extractor/mc-extract-original.py`, `extractor/mc-extract-step-included.py`, and `extractor/step-inclusion.diff`: the original extractor and one-line experiment that processed the controller's `step` action. That experiment also changed scan-phase semantics and is not a validated fix.
- `logs/*.log`: retained nuXmv output from the segmented checks. `run.sh` is the exact script used on Blink; its absolute paths refer to the original temporary directories on that machine.

| Check | Result |
| --- | --- |
| Original voltage invariant | true, 0.03 s |
| Original feedback invariant | false, 0.15 s |
| Coupled feedback invariant | false, 1.78 s |
| Snapshot feedback invariant | true, 0.02 s |
| Original envelope invariant | timeout, 300.01 s, bound 8 |
| Disabled-input envelope invariant | true, 0.07 s |
| Coupled envelope invariant | timeout, 300.00 s, bound 7 |
| Bounded falsification attempt | rejected: infinite-precision real variables cannot be made into a Boolean FSM |

An exact recurrence trace of the original generated model with a permitted
+10 V amplifier input violates the balance envelope at step 80. A separate
80-step trace of the controller-coupled diagnostic at the +90-degree target
stayed within the envelope. Neither trace proves the unbounded
controller-coupled requirement.
